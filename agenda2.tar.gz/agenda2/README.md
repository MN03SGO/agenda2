Hay un error en la duplicacion de actividad en el btn flotante colocar, en vez del StarActivity = intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
